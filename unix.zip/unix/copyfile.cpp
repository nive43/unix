#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include<unistd.h>
int main(int argc,char** argv)
{
	
	//int exist=cfileexist(*(argv+1));
	//int exist1=cfileexist(*(argv+2));
	FILE *fp,*fp1;
	fp=fopen(*(argv+1),"r");
	fp1=fopen(*(argv+2),"W+");
	int bufferlen=255;
	char buffer[bufferlen];
	if(access( *(argv+1), F_OK ) != 0 )
	{
		printf("Input file not found. Quiting!!");
		exit(EXIT_FAILURE);	
	}
	if(fp1!=NULL)
	{
		printf("Output file already exist. Quiting!!");
		exit(EXIT_FAILURE);
	}
	
	while(fgets(buffer,bufferlen,fp)!=NULL);
	{
		fputs(buffer,fp1);
	}
	fclose(fp);
	fclose(fp1);

	return 0;
	
}
