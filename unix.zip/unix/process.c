#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <dos.h>
//#include <wait.h>
#include <stdlib.h>
#include <unistd.h>
 
//#include <sys/wait.h>
//#include <sys/resource.h>

int main()
{
int st;
 int p=fork();
	while(st!=1)
	{
	if(`p==0){
		int child=getpid();
		sleep(5);
	}else if(p>0)
	{
		int parent=getpid();
		sleep(5);
	}
	printf("Enter 1 to kill child");
	scanf("\n%d\n",st);
  
}
kill(child,SIGKILL);
Signal(SIGCHLD, child);
printf("Child died");

	printf("Hello world!\n");
	return 0;
}

